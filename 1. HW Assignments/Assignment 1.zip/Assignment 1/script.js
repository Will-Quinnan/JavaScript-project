console.log("Script File");
document.write(`
<p> 1.	Types of variables from Amazon </p>
<p> 2.	Login ID </p>
<p> 3.	Password </p>
<p> 4.	Mobile number </p>
<p> 5.	Gift cards </p>
<p> 6.	Payments </p>
<p> 7.	Profiles </p>
<p> 8.	Name </p>
<p> 9.	Address </p>
<p> 10.	Language </p>
<p> 11.	Lists </p>
<p> 12.	Cart </p>
<p> 13.	Orders </p>
<p> 14.	Navigation Bar </p>
<p> 15.	Adds </p>
<p> 16.	Keep Shopping for </p> 
<p> 17.	Browsing History </p>
<p> 18.	Buy again </p>
<p> 19.	Amazon live </p>
<p> 20.	Coupons </p>
`)